DATA_URL = 'https://i.mjh.nz/Stirr/app.json.gz'
EPG_URL = 'https://i.mjh.nz/Stirr/all.xml.gz'
ALL = 'all'
MY_CHANNELS = 'my_channels'
