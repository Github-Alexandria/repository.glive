pluginid = 'plugin.video.megaiptv'
host='local'