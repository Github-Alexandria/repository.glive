
channels = [


    {"title": "AWE", "url": "http://n1.klowdtv.net/live1/awe_720p/chunks.m3u8", "image": "None"},
    {"title": "Demand Africa", "url": "https://demandafrica-klowdtv.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "ESTV", "url": "https://estv-klowdtv.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Fido TV", "url": "http://n1.klowdtv.net/live3/fido_720p/chunks.m3u8", "image": "None"},
    {"title": "Game Show Network East", "url": "http://n1.klowdtv.net/live2/gsn_720p/chunks.m3u8", "image": "None"},
    {"title": "HNC Free", "url": "https://hncfree-klowdtv.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "OAN", "url": "http://n1.klowdtv.net/live1/oan_720p/playlist.m3u8", "image": "None"},
    {"title": "OAN", "url": "https://cdn.klowdtv.net/803B48A/oan_aws_ms/OAN.m3u8", "image": "None"},
    {"title": "Pop TV", "url": "http://n1.klowdtv.net/live2/pop_720p/playlist.m3u8", "image": "None"},
    {"title": "QVC Live", "url": "http://n1.klowdtv.net/live2/qvclive_720p/playlist.m3u8", "image": "None"},
    {"title": "Redseat The First", "url": "https://redseat-thefirst-klowdtv.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "SportsGrid", "url": "https://sportsgrid-klowdtv.amagi.tv/playlist.m3u8", "image": "None"},


]


