
channels = [


    {"title": "AdultSwim East", "url": "https://tve-live-lln.warnermediacdn.com/hls/live/2023183/aseast/noslate/VIDEO_3_1928000.m3u8", "image": "https://i.imgur.com/XCSNWZc.png"},
    {"title": "AdultSwim West", "url": "https://tve-live-lln.warnermediacdn.com/hls/live/2023185/aswest/noslate/VIDEO_3_1928000.m3u8", "image": "https://i.imgur.com/XCSNWZc.png"},
    {"title": "Aqua Teen Hunger Force", "url": "https://adultswim-vodlive.cdn.turner.com/live/aqua-teen/stream.m3u8", "image": "https://i.imgur.com/eQYzog8.png"},
    {"title": "Black Jesus", "url": "https://adultswim-vodlive.cdn.turner.com/live/black-jesus/stream.m3u8", "image": "https://i.imgur.com/slawVDH.png"},
    {"title": "Channel 5", "url": "https://adultswim-vodlive.cdn.turner.com/live/channel-5/stream.m3u8", "image": "https://i.imgur.com/3q9NkZJ.jpg"},
    {"title": "Daily Animated", "url": "https://adultswim-vodlive.cdn.turner.com/live/daily_animated_1/stream.m3u8", "image": "None"},
    {"title": "Daily Live Action", "url": "https://adultswim-vodlive.cdn.turner.com/live/daily_liveaction_1/stream.m3u8", "image": "https://i.imgur.com/sLEHqIC.png"},
    {"title": "Dream Corp LLC", "url": "https://adultswim-vodlive.cdn.turner.com/live/DREAM-CORP-LLC/stream.m3u8", "image": "https://i.imgur.com/le0DGBd.png"},
    {"title": "Home Movies", "url": "https://adultswim-vodlive.cdn.turner.com/live/test-2/stream.m3u8", "image": "https://i.imgur.com/zlPbOI0.png"},
    {"title": "Infomercials", "url": "https://adultswim-vodlive.cdn.turner.com/live/infomercials/stream.m3u8", "image": "https://i.imgur.com/yKpo8Ye.jpg"},
    {"title": "Last Stream on the Left", "url": "https://adultswim-vodlive.cdn.turner.com/live/lsotl/stream.m3u8", "image": "https://i.imgur.com/Gu7x3QD.png"},
    {"title": "Metalocalypse", "url": "https://adultswim-vodlive.cdn.turner.com/live/metalocalypse/stream.m3u8", "image": "https://i.imgur.com/rYIysEl.png"},
    {"title": "Mr. Pickles", "url": "https://adultswim-vodlive.cdn.turner.com/live/mr-pickles/stream.m3u8", "image": "https://static.next-episode.net/tv-shows-images/huge/mr.-pickles.jpg"},
    {"title": "Off the Air", "url": "https://adultswim-vodlive.cdn.turner.com/live/off-the-air/stream.m3u8", "image": "https://i.imgur.com/rjsOgCi.jpg"},
    {"title": "Primal", "url": "https://adultswim-vodlive.cdn.turner.com/live/primal/stream.m3u8", "image": "None"},
    {"title": "Rick and Morty", "url": "https://adultswim-vodlive.cdn.turner.com/live/rick-and-morty/stream.m3u8", "image": "https://i.imgur.com/7bZnIJ0.png"},
    {"title": "Robot Chicken", "url": "https://adultswim-vodlive.cdn.turner.com/live/robot-chicken/stream.m3u8", "image": "https://i.imgur.com/ZUg5vhn.png"},
    {"title": "Samurai Jack", "url": "https://adultswim-vodlive.cdn.turner.com/live/samurai-jack/stream.m3u8", "image": "https://i.imgur.com/nxvtBCD.jpg"},
    {"title": "Squidbillies", "url": "https://adultswim-vodlive.cdn.turner.com/live/squidbillies/stream.m3u8", "image": "None"},
    {"title": "Squidbillies", "url": "https://adultswim-vodlive.cdn.turner.com/live/squidbillies/stream_7.m3u8", "image": "https://i.imgur.com/zSs1e5z.png"},
    {"title": "Superjail!", "url": "https://adultswim-vodlive.cdn.turner.com/live/superjail/stream.m3u8", "image": "https://i.imgur.com/K3nLFU9.png"},
    {"title": "The Eric Andre Show", "url": "https://adultswim-vodlive.cdn.turner.com/live/eric-andre/stream.m3u8", "image": "https://i.imgur.com/GBlHt4r.png"},
    {"title": "The Venture Bros.", "url": "https://adultswim-vodlive.cdn.turner.com/live/venture-bros/stream.m3u8", "image": "https://i.imgur.com/kru210h.png"},
    {"title": "Tim and Eric", "url": "https://adultswim-vodlive.cdn.turner.com/tim-and-eric/stream.m3u8", "image": "https://i.imgur.com/9lsXliT.png"},
    {"title": "Toonami", "url": "https://adultswim-vodlive.cdn.turner.com/live/toonami/stream.m3u8", "image": "https://i.imgur.com/sLEHqIC.png"},
    {"title": "Williams Stream", "url": "https://adultswim-vodlive.cdn.turner.com/live/williams-stream/stream_html5.m3u8", "image": "https://i.imgur.com/64uOrnR.png"},
    {"title": "Your Pretty Face Is Going To Hell", "url": "https://adultswim-vodlive.cdn.turner.com/live/ypf/stream.m3u8", "image": "None"},
    {"title": "Your Pretty Face Is Going to Hell", "url": "https://adultswim-vodlive.cdn.turner.com/live/ypf/stream_7.m3u8", "image": "https://i.imgur.com/v9HBW7B.jpg"},


]


