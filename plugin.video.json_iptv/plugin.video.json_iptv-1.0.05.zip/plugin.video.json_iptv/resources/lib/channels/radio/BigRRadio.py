
channels = [


    {"title": "1Faith - Hits", "url": "http://bigrradio.cdnstream1.com/5180_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "1Faith - Worship", "url": "http://bigrradio.cdnstream1.com/5179_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "70s and 80s Pop Mix", "url": "http://bigrradio.cdnstream1.com/5181_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "70s FM", "url": "http://bigrradio.cdnstream1.com/5182_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "80s and 90s Pop Mix", "url": "http://bigrradio.cdnstream1.com/5183_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "80s FM", "url": "http://bigrradio.cdnstream1.com/5184_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "80s Lite", "url": "http://bigrradio.cdnstream1.com/5185_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "80s Metal FM", "url": "http://bigrradio.cdnstream1.com/5186_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "90s Alternative Rock", "url": "http://bigrradio.cdnstream1.com/5187_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "90s FM", "url": "http://bigrradio.cdnstream1.com/5188_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "100.3 The Rock Mix", "url": "http://bigrradio.cdnstream1.com/5172_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "100.5 Classic Rock", "url": "http://bigrradio.cdnstream1.com/5171_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "100.7 The Mix", "url": "http://bigrradio.cdnstream1.com/5173_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "100.8 The Hawk", "url": "http://bigrradio.cdnstream1.com/5174_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "100.9 Star Country", "url": "http://bigrradio.cdnstream1.com/5175_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "101.1 The Beat", "url": "http://bigrradio.cdnstream1.com/5176_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "101.6 Adult Warm Hits", "url": "http://bigrradio.cdnstream1.com/5177_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "108.1 Jamz", "url": "http://bigrradio.cdnstream1.com/5178_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Alternative Rock", "url": "http://bigrradio.cdnstream1.com/5189_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Christmas Classics", "url": "http://bigrradio.cdnstream1.com/5190_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Christmas Country", "url": "http://bigrradio.cdnstream1.com/5191_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Christmas Rock", "url": "http://bigrradio.cdnstream1.com/5192_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Christmas Top40", "url": "http://bigrradio.cdnstream1.com/5193_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Classic R&B", "url": "http://bigrradio.cdnstream1.com/5194_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Coffee House", "url": "http://bigrradio.cdnstream1.com/5156_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Country Mix", "url": "http://bigrradio.cdnstream1.com/5196_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Country Oldies", "url": "http://bigrradio.cdnstream1.com/5195_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Erin's Chill", "url": "http://bigrradio.cdnstream1.com/5197_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Explicit Top 40", "url": "http://bigrradio.cdnstream1.com/5237_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Golden Oldies", "url": "http://bigrradio.cdnstream1.com/5198_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Gospel Channel", "url": "http://bigrradio.cdnstream1.com/5199_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Grunge FM", "url": "http://bigrradio.cdnstream1.com/5200_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Post Grunge Rock", "url": "http://bigrradio.cdnstream1.com/5203_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "R&B", "url": "http://bigrradio.cdnstream1.com/5202_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Rock Top 40", "url": "http://bigrradio.cdnstream1.com/5204_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Smooth Jazz", "url": "http://bigrradio-edge1.cdnstream.com/5123_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "The Love Channel", "url": "http://bigrradio.cdnstream1.com/5207_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "The Wave", "url": "http://bigrradio.cdnstream1.com/5208_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Vocal Jazz", "url": "http://bigrradio-edge1.cdnstream.com/5127_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"},
    {"title": "Yacht Rock", "url": "http://bigrradio.cdnstream1.com/5256_128", "image": "http://live2.mystreamplayer.com/configs/images/bigr-fbimage.png"}


]


