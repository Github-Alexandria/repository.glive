# -*- coding: utf-8 -*-

import sys

from resources.lib.modules import control

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])

addonFanart = control.addonFanart()
artwork_enabled = control.setting('addon.artwork')


class main_menu:
    def root(self):
        self.addDirectoryItem('Json IPTV Menu', 'json_iptv_menu', None)
        self.addDirectoryItem('Site IPTV Menu', 'site_iptv_menu', None)
        self.addDirectoryItem('Site Music Menu', 'site_music_menu', None)
        self.addDirectoryItem('Tools Menu', 'tools_menu', 'DefaultAddonService.png')
        self.endDirectory()


    def site_iptv_menu(self):
        self.addDirectoryItem('UStvGO', 'ustvgo_menu', None)
        self.addDirectoryItem('UStv247', 'ustv247_menu', None)
        self.addDirectoryItem('WatchNewsLive', 'watchnewslive_menu', None)
        self.addDirectoryItem('WatchYourTV', 'watchyourtv_menu', None)
        self.endDirectory()


    def site_music_menu(self):
        self.addDirectoryItem('NightRide: StreamSafe Songs', 'nightride_streamsafe_menu', None)
        self.addDirectoryItem('NightRide: Stations', 'nightride_stations_menu', None)
        self.endDirectory()


    def tools(self):
        self.addDirectoryItem('(About/ReadMe/Help)', 'view_information', 'DefaultIconInfo.png', isFolder=False)
        self.addDirectoryItem('Open Settings', 'open_settings&query=0.0', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem('View ChangeLog', 'view_changelog', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem('View DebugLog', 'view_debuglog', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem('Empty DebugLog', 'empty_debuglog', 'DefaultAddonProgram.png', isFolder=False)
        self.endDirectory()


    def addDirectoryItem(self, title, query, icon, isAction=True, isFolder=True):
        try:
            url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
            try:
                item = control.item(label=title, offscreen=True)
            except:
                item = control.item(label=title)
            item.setArt({'icon': icon, 'thumb': icon, 'fanart': addonFanart})
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
        except Exception:
            log_utils.log('addDirectory', 1)
            pass


    def addDirectory(self, items, queue=False, isFolder=True):
        if items == None or len(items) == 0:
            control.idle()
            #sys.exit()
        for i in items:
            try:
                url = '%s?action=%s&url=%s' % (sysaddon, i['action'], i['url'])
                title = i['title']
                if artwork_enabled == 'true':
                    icon = i['image'] if not i['image'] == (None or 'None') else 'DefaultVideo.png'
                else:
                    icon = 'DefaultVideo.png'
                try:
                    item = control.item(label=title, offscreen=True)
                except:
                    item = control.item(label=title)
                item.setProperty('IsPlayable', 'true')
                item.setArt({'icon': icon, 'thumb': icon, 'fanart': addonFanart})
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
            except Exception:
                log_utils.log('addDirectory', 1)
                pass
        self.endDirectory()


    def endDirectory(self, cached=True):
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=cached)


