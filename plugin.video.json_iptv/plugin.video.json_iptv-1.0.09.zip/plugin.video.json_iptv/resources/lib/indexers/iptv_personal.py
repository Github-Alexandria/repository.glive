# -*- coding: utf-8 -*-

from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import directory as lets
from resources.lib.modules import log_utils


class Indexer:
    def __init__(self):
        self.notes = 'Examples and a test list can be found here... https://raw.githubusercontent.com/jewbmx/json_iptv_lists/main/example_test_list.json'


    def personal_lists(self):
        the_list = []
        try:
            personal_list1 = control.setting('personal.list1')
            if personal_list1 == 'true':
                title, url, image = self.parse_settings('personal.list1.title', 'personal.list1.link', 'personal.list1.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list2 = control.setting('personal.list2')
            if personal_list2 == 'true':
                title, url, image = self.parse_settings('personal.list2.title', 'personal.list2.link', 'personal.list2.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list3 = control.setting('personal.list3')
            if personal_list3 == 'true':
                title, url, image = self.parse_settings('personal.list3.title', 'personal.list3.link', 'personal.list3.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list4 = control.setting('personal.list4')
            if personal_list4 == 'true':
                title, url, image = self.parse_settings('personal.list4.title', 'personal.list4.link', 'personal.list4.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list5 = control.setting('personal.list5')
            if personal_list5 == 'true':
                title, url, image = self.parse_settings('personal.list5.title', 'personal.list5.link', 'personal.list5.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list6 = control.setting('personal.list6')
            if personal_list6 == 'true':
                title, url, image = self.parse_settings('personal.list6.title', 'personal.list6.link', 'personal.list6.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list7 = control.setting('personal.list7')
            if personal_list7 == 'true':
                title, url, image = self.parse_settings('personal.list7.title', 'personal.list7.link', 'personal.list7.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list8 = control.setting('personal.list8')
            if personal_list8 == 'true':
                title, url, image = self.parse_settings('personal.list8.title', 'personal.list8.link', 'personal.list8.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list9 = control.setting('personal.list9')
            if personal_list9 == 'true':
                title, url, image = self.parse_settings('personal.list9.title', 'personal.list9.link', 'personal.list9.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            personal_list10 = control.setting('personal.list10')
            if personal_list10 == 'true':
                title, url, image = self.parse_settings('personal.list10.title', 'personal.list10.link', 'personal.list10.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'personal_scrape'})
            lets.addDirectory(the_list, content='episodes')
            return the_list
        except:
            log_utils.log('personal_lists', 1)
            return the_list


    def personal_channels(self):
        the_list = []
        try:
            personal_channel1 = control.setting('personal.channel1')
            if personal_channel1 == 'true':
                title, url, image = self.parse_settings('personal.channel1.title', 'personal.channel1.link', 'personal.channel1.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel2 = control.setting('personal.channel2')
            if personal_channel2 == 'true':
                title, url, image = self.parse_settings('personal.channel2.title', 'personal.channel2.link', 'personal.channel2.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel3 = control.setting('personal.channel3')
            if personal_channel3 == 'true':
                title, url, image = self.parse_settings('personal.channel3.title', 'personal.channel3.link', 'personal.channel3.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel4 = control.setting('personal.channel4')
            if personal_channel4 == 'true':
                title, url, image = self.parse_settings('personal.channel4.title', 'personal.channel4.link', 'personal.channel4.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel5 = control.setting('personal.channel5')
            if personal_channel5 == 'true':
                title, url, image = self.parse_settings('personal.channel5.title', 'personal.channel5.link', 'personal.channel5.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel6 = control.setting('personal.channel6')
            if personal_channel6 == 'true':
                title, url, image = self.parse_settings('personal.channel6.title', 'personal.channel6.link', 'personal.channel6.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel7 = control.setting('personal.channel7')
            if personal_channel7 == 'true':
                title, url, image = self.parse_settings('personal.channel7.title', 'personal.channel7.link', 'personal.channel7.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel8 = control.setting('personal.channel8')
            if personal_channel8 == 'true':
                title, url, image = self.parse_settings('personal.channel8.title', 'personal.channel8.link', 'personal.channel8.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel9 = control.setting('personal.channel9')
            if personal_channel9 == 'true':
                title, url, image = self.parse_settings('personal.channel9.title', 'personal.channel9.link', 'personal.channel9.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            personal_channel10 = control.setting('personal.channel10')
            if personal_channel10 == 'true':
                title, url, image = self.parse_settings('personal.channel10.title', 'personal.channel10.link', 'personal.channel10.image')
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            lets.addDirectory(the_list, content='episodes')
            return the_list
        except:
            log_utils.log('personal_channels', 1)
            return the_list


    def scrape_channel(self, url):
        the_list = []
        try:
            page = client.scrapePage(url).json()
            channels = page['channels']
            for channel in channels:
                title = client.replaceHTMLCodes(channel['title'])
                url = channel['url']
                image = channel['image']
                the_list.append({'title': title, 'url': url, 'image': image, 'action': 'play'})
            lets.addDirectory(the_list, content='episodes')
            return the_list
        except:
            log_utils.log('scrape_channel', 1)
            return the_list


    def parse_settings(self, title, url, image):
        _title = _url = _image = ''
        try:
            _title = control.setting(title)
            _title = client.replaceHTMLCodes(_title)
            _url = control.setting(url)
            _image = control.setting(image)
            return _title, _url, _image
        except:
            log_utils.log('parse_settings', 1)
            return _title, _url, _image


