
channels = [


    {"title": "Beat Blender", "url": "https://ice4.somafm.com/beatblender-128-mp3", "image": "https://i.imgur.com/HKvTE0g.png"},
    {"title": "Black Rock FM", "url": "https://ice4.somafm.com/brfm-128-mp3", "image": "https://i.imgur.com/jbhgoMp.jpg"},
    {"title": "Boot Liquor", "url": "https://ice4.somafm.com/bootliquor-320-mp3", "image": "https://i.imgur.com/4rrW8WQ.jpg"},
    {"title": "Cliqhop IDM", "url": "https://ice4.somafm.com/cliqhop-256-mp3", "image": "https://i.imgur.com/yf6sTkp.png"},
    {"title": "Covers", "url": "https://ice4.somafm.com/covers-128-mp3", "image": "https://i.imgur.com/tY8oIxQ.jpg"},
    {"title": "Deep Space One", "url": "http://ice4.somafm.com/deepspaceone-128-mp3", "image": "https://i.imgur.com/Trx0N2f.gif"},
    {"title": "DEF CON Radio", "url": "https://ice4.somafm.com/defcon-256-mp3", "image": "https://i.imgur.com/aLK50mL.png"},
    {"title": "Digitalis", "url": "https://ice4.somafm.com/digitalis-128-mp3", "image": "https://i.imgur.com/cxRysOz.png"},
    {"title": "Drone Zone", "url": "http://ice4.somafm.com/dronezone-256-mp3", "image": "https://i.imgur.com/yLlWw7f.jpg"},
    {"title": "Dub Step Beyond", "url": "https://ice4.somafm.com/dubstep-256-mp3", "image": "https://i.imgur.com/s61Tk7Q.png"},
    {"title": "Fluid", "url": "https://ice4.somafm.com/fluid-128-mp3", "image": "https://i.imgur.com/02GsvrN.jpg"},
    {"title": "Folk Forward", "url": "https://ice4.somafm.com/folkfwd-128-mp3", "image": "https://i.imgur.com/ddBqPOy.jpg"},
    {"title": "Groove Salad Classic", "url": "https://ice4.somafm.com/gsclassic-128-mp3", "image": "https://i.imgur.com/wvFInGf.jpg"},
    {"title": "Groove Salad", "url": "http://ice4.somafm.com/groovesalad-256-mp3", "image": "https://i.imgur.com/3V7QUEp.png"},
    {"title": "Heavyweight Reggae", "url": "https://ice4.somafm.com/reggae-256-mp3", "image": "https://i.imgur.com/jYG9sHq.png"},
    {"title": "Illinois Street Lounge", "url": "https://ice4.somafm.com/illstreet-128-mp3", "image": "https://i.imgur.com/t4hwyjg.jpg"},
    {"title": "Indie Pop Rocks!", "url": "https://ice4.somafm.com/indiepop-128-mp3", "image": "https://i.imgur.com/Y4r4JjA.jpg"},
    {"title": "Left Coast 70s", "url": "https://ice4.somafm.com/seventies-320-mp3", "image": "https://i.imgur.com/iYivXrP.jpg"},
    {"title": "Lush", "url": "https://ice4.somafm.com/lush-128-mp3", "image": "https://i.imgur.com/OMC0vgG.jpg"},
    {"title": "Metal Detector", "url": "https://ice4.somafm.com/metal-128-mp3", "image": "https://i.imgur.com/00MKd51.png"},
    {"title": "Mission Control", "url": "https://ice4.somafm.com/missioncontrol-128-mp3", "image": "https://i.imgur.com/67KH9qh.jpg"},
    {"title": "N5MD Radio", "url": "https://ice4.somafm.com/n5md-128-mp3", "image": "https://i.imgur.com/wgVOXwl.png"},
    {"title": "PopTron", "url": "https://ice4.somafm.com/poptron-128-mp3", "image": "https://i.imgur.com/mljLh6s.png"},
    {"title": "Secret Agent", "url": "https://ice4.somafm.com/secretagent-128-mp3", "image": "https://i.imgur.com/mS4ot4g.jpg"},
    {"title": "Seven Inch Soul", "url": "https://ice4.somafm.com/7soul-128-mp3", "image": "https://i.imgur.com/pf4RAGW.png"},
    {"title": "SF 10-33", "url": "https://ice4.somafm.com/sf1033-128-mp3", "image": "https://i.imgur.com/czXx3iL.png"},
    {"title": "SF Police Scanner", "url": "https://ice4.somafm.com/scanner-128-mp3", "image": "https://i.imgur.com/2CeN3UB.png"},
    {"title": "SomaFM Live", "url": "https://ice4.somafm.com/live-128-mp3", "image": "https://i.imgur.com/FjAFbiF.jpg"},
    {"title": "SomaFM Specials", "url": "https://ice4.somafm.com/specials-128-mp3", "image": "https://i.imgur.com/7T2wszH.jpg"},
    {"title": "Sonic Universe", "url": "https://ice4.somafm.com/sonicuniverse-256-mp3", "image": "https://i.imgur.com/LM2ywC9.jpg"},
    {"title": "Space Station Soma", "url": "https://ice4.somafm.com/spacestation-128-mp3", "image": "https://i.imgur.com/twFtoCm.jpg"},
    {"title": "Suburbs of Goa", "url": "https://ice4.somafm.com/suburbsofgoa-128-mp3", "image": "https://i.imgur.com/q8DwawH.jpg"},
    {"title": "Synphaera Radio", "url": "https://ice4.somafm.com/synphaera-256-mp3", "image": "https://i.imgur.com/Pv0nimy.jpg"},
    {"title": "The Trip", "url": "https://ice4.somafm.com/thetrip-128-mp3", "image": "https://i.imgur.com/8V9qodX.jpg"},
    {"title": "ThistleRadio", "url": "https://ice4.somafm.com/thistle-128-mp3", "image": "https://i.imgur.com/ry6yril.png"},
    {"title": "Underground 80s", "url": "https://ice4.somafm.com/u80s-256-mp3", "image": "https://i.imgur.com/9BlAJp7.png"},
    {"title": "Vaporwaves", "url": "https://ice4.somafm.com/vaporwaves-128-mp3", "image": "https://i.imgur.com/1zUGpz3.jpg"}


]


