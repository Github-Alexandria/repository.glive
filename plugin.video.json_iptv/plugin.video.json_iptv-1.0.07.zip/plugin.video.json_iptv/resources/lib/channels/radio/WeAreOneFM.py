
channels = [


    {"title": "Club Time FM HQ", "url": "https://listener2.aachd.tb-group.fm/clt-hd.aac", "image": "https://i.imgur.com/UT3Dq0Q.png"},
    {"title": "Club Time FM LOW", "url": "https://listener2.aachd.tb-group.fm/clt-low.aac", "image": "https://i.imgur.com/UT3Dq0Q.png"},
    {"title": "Club Time FM MED", "url": "https://mp3.stream.tb-group.fm/clt.mp3", "image": "https://i.imgur.com/UT3Dq0Q.png"},
    {"title": "Core Time FM HQ", "url": "https://listener3.aachd.tb-group.fm/ct-hd.aac", "image": "https://i.imgur.com/FwNvwuF.png"},
    {"title": "Core Time FM LOW", "url": "https://listener3.aachd.tb-group.fm/ct-low.aac", "image": "https://i.imgur.com/FwNvwuF.png"},
    {"title": "Core Time FM MED", "url": "https://mp3.stream.tb-group.fm/ct.mp3", "image": "https://i.imgur.com/FwNvwuF.png"},
    {"title": "Hard Base FM HQ", "url": "https://listener3.aachd.tb-group.fm/hb-hd.aac", "image": "https://i.imgur.com/Zm3lyjb.png"},
    {"title": "Hard Base FM LOW", "url": "https://listener3.aachd.tb-group.fm/hb-low.aac", "image": "https://i.imgur.com/Zm3lyjb.png"},
    {"title": "Hard Base FM MED", "url": "https://mp3.stream.tb-group.fm/hb.mp3", "image": "https://i.imgur.com/Zm3lyjb.png"},
    {"title": "House Time FM HQ", "url": "https://listener1.aachd.tb-group.fm/ht-hd.aac", "image": "https://i.imgur.com/xoF2xz2.png"},
    {"title": "House Time FM LOW", "url": "https://listener1.aachd.tb-group.fm/ht-low.aac", "image": "https://i.imgur.com/xoF2xz2.png"},
    {"title": "House Time FM MED", "url": "https://mp3.stream.tb-group.fm/ht.mp3", "image": "https://i.imgur.com/xoF2xz2.png"},
    {"title": "Replay FM HQ", "url": "https://listener3.aachd.tb-group.fm/rp-hd.aac", "image": "https://i.imgur.com/daBSiq2.png"},
    {"title": "Replay FM LOW", "url": "https://listener3.aachd.tb-group.fm/rp-low.aac", "image": "https://i.imgur.com/daBSiq2.png"},
    {"title": "Replay FM MED", "url": "https://mp3.stream.tb-group.fm/rp.mp3", "image": "https://i.imgur.com/daBSiq2.png"},
    {"title": "Tea Time FM HQ", "url": "https://listener3.aachd.tb-group.fm/tt-hd.aac", "image": "https://i.imgur.com/MylhwXh.png"},
    {"title": "Tea Time FM LOW", "url": "https://listener3.aachd.tb-group.fm/tt-low.aac", "image": "https://i.imgur.com/MylhwXh.png"},
    {"title": "Tea Time FM MED", "url": "https://mp3.stream.tb-group.fm/tt.mp3", "image": "https://i.imgur.com/MylhwXh.png"},
    {"title": "Techno Base FM HQ", "url": "https://listener1.aachd.tb-group.fm/tb-hd.aac", "image": "https://i.imgur.com/fXEhBgm.png"},
    {"title": "Techno Base FM LOW", "url": "https://listener1.aacl.tb-group.fm/tb-low.aac", "image": "https://i.imgur.com/fXEhBgm.png"},
    {"title": "Techno Base FM MED", "url": "https://mp3.stream.tb-group.fm/tb.mp3", "image": "https://i.imgur.com/fXEhBgm.png"},
    {"title": "Trance Base FM HQ", "url": "https://listener2.aachd.tb-group.fm/trb-hd.aac", "image": "https://i.imgur.com/dCBXO3P.png"},
    {"title": "Trance Base FM LOW", "url": "https://listener2.aachd.tb-group.fm/trb-low.aac", "image": "https://i.imgur.com/dCBXO3P.png"},
    {"title": "Trance Base FM MED", "url": "https://mp3.stream.tb-group.fm/trb.mp3", "image": "https://i.imgur.com/dCBXO3P.png"},


]


