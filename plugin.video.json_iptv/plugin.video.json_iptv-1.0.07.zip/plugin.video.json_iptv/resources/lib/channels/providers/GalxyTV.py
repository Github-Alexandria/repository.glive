
channels = [


    {"title": "Adventure of Sonic the Hedgehog", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=2365", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/zaH9nqZ1zTjfFH0DmYTW9XjEIfPPL1mhtMHRLZWN.png"},
    {"title": "Business Rockstars", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=77", "image": "https://galxy.tv/storage/live-tv/channel-logos/iFHe67qsFks6oW3CoJqgmT5DgTzRdNKACnJzTl8j.png"},
    {"title": "CinePride", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1871", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/hAWYM7F3QL1eYpn53UYdlLRXTjMUVKrB001poodr.png"},
    {"title": "Don.", "url": "https://content.uplynk.com/channel/7c4b402081484be6aaad367f6a1224d7.m3u8", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/LXe9XYeyNgbvzyQ004372skB79FAiPYfRvKOxkW0.png"},
    {"title": "Dungeon", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=79", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/uofebYTFJ0XtmiC8OG7MW4eZvAZrobmOyLDxdtTu.png"},
    {"title": "El Conflicto!", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=80", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/WDIFirclv0BvLYHbopJqX3PM2YtJzizRYzPXE2yj.png"},
    {"title": "Entrepreneur TV", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=2506", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/0Z1glc75xmNojRa9KyWstfrjBih95ZwA1mb5ywGU.png"},
    {"title": "FrightFlix", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=81", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/cRLgVMvkZwozTTg0Bs0151KxArVv1lYuNA7IIdjr.png"},
    {"title": "Indistry", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=82", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/0bC8fBEibtEpVyhwgiyVQNZEucI6U610nWCADPjU.png"},
    {"title": "Qello Concerts", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1936", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/5MehnrNHgpbp4cMOXiiiwCoVlZbNGf6eExGiUinJ.png"},
    {"title": "Screendreams", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=83", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/Cr1KRm1CC0TD3Od6HTrgn68WR42pG2c1a0ZsA0C4.png"},
    {"title": "Slopes", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=72", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/G9fcAQadF6IcSqAvLQjkdfkhSo3kH3XIGSgzcQpf.png"},
    {"title": "Stingray Classic Rock", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1942", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/XdQ06cEmXkqnWuFnBXyfRXxq7qQDID4AJtfKkQIW.png"},
    {"title": "Stingray Classica", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=2373", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/xOLjwUCRC3LpYpcS6bPwAVwYoAmqRMYjcIpKL9od.png"},
    {"title": "Stingray Cmusic", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1937", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/39RIuJV94hx6qLAVve3pgQYYqJmj3lbUXn1xpiWK.png"},
    {"title": "Stingray dJazz", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1939", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/TolbD4QDeujexlnDpeFHTJtKz4QVPAO8tGSzRCwe.png"},
    {"title": "Stingray Everything 80s", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1948", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/y2uaR9d9ESdV1iBu0e8aWP8Egj0xXYx67nZktFhe.png"},
    {"title": "Stingray Flashback 70s", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=2372", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/fdLnjFVHgmMyumBlGnt4p7UTtPGOt9sSPlreRzoS.png"},
    {"title": "Stingray Greatest Hits", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1951", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/4ZxI7M6M5KlpcIrzrcAHbmCw8aOg1E0fTBDjjtmr.png"},
    {"title": "Stingray Hit List", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1945", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/wWSdxvNkRto897anmx260L03wZAtQBICS78SZfRX.png"},
    {"title": "Stingray Hot Country", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1946", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/9IEVg6ltNLGuXWDybiaEw0WBeUXX1WLIggmgbtgo.png"},
    {"title": "Stingray Karaoke", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1940", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/BHlttYbyHEtm70XQBL1km4h9tLWluwpvVwoqOXMV.png"},
    {"title": "Stingray Natur Escape", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1941", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/dJlsiUO19b0sIFQTkCBnSze3PkEsolHavuiuceJy.png"},
    {"title": "Stingray Pop Adult", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1944", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/r2VkA9clGo5DkHzDBp8cwgSKDqrYwcgZyvo2o6tY.png"},
    {"title": "Stingray Rock Alternative", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1943", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/9yBs3Z77mDZlFdwA73wGkjcDvdlJZwr2ZT0HA7E6.png"},
    {"title": "Stingray Soul Storm", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1950", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/UBCMxTglB9mJj7goaVJNh07JPtPTt0cycduj58zF.png"},
    {"title": "Stingray Today's Latin Pop", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1952", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/nKaBl4FaLVWBDDoHnVLbmzS09x1Gmc25dMOTcTmh.png"},
    {"title": "Stingray Urban Hits", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1949", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/6WdEf2NyiyQeTt8zW0aBxf3mG4Cc0DwWBqIZ4ZG8.png"},
    {"title": "Watch it Kid!", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=84", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/thXaxvhTCZ59IhqUodrjuWjrC8KcGYvxklzrZpaN.png"},
    {"title": "Watch it Scream!", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=85", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/bAD6zfRE1r2H6Oue1BBFPO5AK4dsQZTEy6Sava2e.png"},
    {"title": "XFCTV> Fightworld", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1985", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/aZ8E901m6tI7l39R1B4ohX3fQy19HLBrGspdqxQ3.png"},
    {"title": "ZAS", "url": "https://stream-us-east-1.getpublica.com/playlist.m3u8?live=1&network_id=1972", "image": "https://s3.amazonaws.com/mtdb.galxy.prod/storage/live-tv/channel-logos/F8Iqr52ZIRs4CvmEm8ToQ0GuMw7oFXWTEaQUz3lK.png"},


]


