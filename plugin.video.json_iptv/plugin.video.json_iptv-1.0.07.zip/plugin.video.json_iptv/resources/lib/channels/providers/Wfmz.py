
channels = [


    {"title": "WFMZ 69 News", "url": "https://cdn.jaybirdtv.com/wfmz/channel/10/master.m3u8", "image": "None"},
    {"title": "WFMZ Bird Camera", "url": "https://cdn.jaybirdtv.com/wfmz/13/live/master.m3u8", "image": "None"},
    {"title": "WFMZ Dorney Park Camera", "url": "https://cdn.jaybirdtv.com/wfmz/5/live/master.m3u8", "image": "None"},
    {"title": "WFMZ DT1", "url": "https://cdn.jaybirdtv.com/wfmz/channel/1/master.m3u8", "image": "None"},
    {"title": "WFMZ DT2", "url": "https://cdn.jaybirdtv.com/wfmz/channel/2/master.m3u8", "image": "None"},
    {"title": "WFMZ PennST Camera", "url": "https://cdn.jaybirdtv.com/wfmz/6/live/master.m3u8", "image": "None"},
    {"title": "WFMZ PPL Tower Camera", "url": "https://cdn.jaybirdtv.com/wfmz/channel/9/master.m3u8", "image": "None"},
    {"title": "WFMZ Tower Camera", "url": "https://cdn.jaybirdtv.com/wfmz/8/live/master.m3u8", "image": "None"},
    {"title": "WFMZ Traffic", "url": "https://cdn.jaybirdtv.com/wfmz/channel/7/master.m3u8", "image": "None"},


]


